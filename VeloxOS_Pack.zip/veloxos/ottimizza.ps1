$imgPath = Join-Path $PSScriptRoot "images\background.jpg"

function Set-Wallpaper($path) {
    Add-Type @"
    using System.Runtime.InteropServices;

    public class Wallpaper {
        [DllImport("user32.dll",SetLastError=true)]
        public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
    }
"@

    [Wallpaper]::SystemParametersInfo(20, 0, $path, 3)
}

if (Test-Path $imgPath) {
    Set-Wallpaper $imgPath
} else {
    Write-Output "Immagine background.jpg non trovata in $imgPath"
}

Write-Output "Applicando ottimizzazioni VeloxOS..."
# Qui inserisci il resto delle tue ottimizzazioni
